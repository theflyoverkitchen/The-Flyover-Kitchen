THE FLYOVER KITCHEN — Starter website

Open index.html in a browser to preview.

Included:
- Responsive customer menu
- Cart quantity controls and WhatsApp order message
- Demo admin login (mobile shown: 8868089726)
- Add product, update price, toggle availability ON/OFF, delete product
- Add vendor entries (demo)

Important limitations:
This is a front-end prototype. Data is stored only in the current browser using localStorage.
It is NOT yet a live multi-vendor system: vendors do not have separate secure logins, delivery partner
accounts are not active, and changes are not shared across devices. Before public launch, connect
a secure backend/database and authentication, route orders to the selected vendor, and replace the
demo password. The WhatsApp order currently goes to 918868089726 (India country code + mobile).
Demo password: flyover123 — change before any public deployment.
